import React,{Component} from 'react';
import './App.css';
//import { BrowserRouter, NavLink, Route, Router } from "react-router-dom";

class Header extends Component{
  render(){
  return (
   <div className = "header">
     Header
  
    <div className = "footer">
      footer
    </div>
    </div>
    
  );
  }
}

export default Header;
